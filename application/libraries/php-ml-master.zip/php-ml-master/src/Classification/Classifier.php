<?php

declare(strict_types=1);

namespace Phpml\Classification;

use Phpml\Estimator;

interface Classifier extends Estimator
{
}
