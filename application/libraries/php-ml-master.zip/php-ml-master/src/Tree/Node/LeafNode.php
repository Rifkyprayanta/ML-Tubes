<?php

declare(strict_types=1);

namespace Phpml\Tree\Node;

interface LeafNode
{
}
