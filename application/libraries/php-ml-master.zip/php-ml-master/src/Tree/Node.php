<?php

declare(strict_types=1);

namespace Phpml\Tree;

interface Node
{
}
